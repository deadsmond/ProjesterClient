import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ProjesterClient {

    private static PrintWriter out;
    private static Socket serverSocket;
    private static BufferedReader in;
    private static String outputFromServer;
    private static String userInput = "";
    private static String nick;
    private static String room;
    private static int port;

    public static void main(String[] args) {
        System.out.println("Client started...");

        // Add parameters:
        // Run / Edit configurations -> program arguments

        // hardcoded default server port

        port = 12314;

        // initialize parameters
        String choice;
        String host;
        if(args.length == 4){
            host = args[0];
            nick = args[1];
            room = args[2];
            choice = args[3];
        }else{
            System.err.println("Wrong arguments");
            return;
        }

        // check parameters
        if(!(choice.equals("chat") || choice.equals("file"))){
            System.err.println("Wrong value of choice (chat,file - " + choice + ")");
            return;
        }

        // connection protocol
        System.out.println("Starting connection protocol:");
        try {
            // get room data
            serverSocket = new Socket(host, port);
            out = new PrintWriter(serverSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));

            // send nick
            System.out.println("Sending nick...");
            sendWord(nick, 32);
            System.out.println("Nick sent successfully.");

            // send room
            System.out.println("Sending room...");
            sendWord("12", 32);
            System.out.println("Room sent successfully.");

            // check if nick hasn't been taken
            outputFromServer = in.readLine();
            if(outputFromServer.contains("This nick has already been taken")){
                System.err.println("This nick has already been taken, please try again");
                System.exit(1);
            }else if(outputFromServer.equals("No Room is available right now, try again later")){
                System.err.println("No Room is available right now, try again later");
                System.exit(1);
            }

            System.out.println("Waiting for port...");
            port = Integer.parseInt(outputFromServer);
            System.out.println("Port received: "+ port);

            // connect to the room
            System.out.println("Connecting to the room...");
            serverSocket = new Socket(host, port);
            System.out.println("Socket passed");
            in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
            System.out.println("New input stream passed");
            out = new PrintWriter(serverSocket.getOutputStream(), true);
            System.out.println("New output stream passed");
            System.out.println("Connected to the room successfully.");

            // send choice
            System.out.println("Sending choice...");
            sendWord(choice, 32);
            System.out.println("Wait for server response...");

            //check choice
            outputFromServer = in.readLine();
            if(!outputFromServer.equals("accepted")){
                System.err.println("Wrong choice - send: "+ outputFromServer);
                System.exit(1);
            }
            System.out.println("Choice accepted.");

            switch(choice){
                case "chat":
                    // start asynchronous chat
                    System.out.println("Starting asynchronous chat...");
                    System.out.println("Asynchronous INPUT running...");

                    // start asynchronous output
                    Output threadOutput = new Output();
                    threadOutput.start();
                    System.out.println("Asynchronous OUTPUT running...");

                    break;
                case "file":
                    //start file service
                    Scanner input = new Scanner(System.in);
                    System.out.println("File console activated. Please choose form of transfer and file name:");
                    while(!(userInput = input.nextLine()).equals("@exit")){
                        switch (userInput.split(" ")[0]) {
                            case "@upload":
                                try {
                                    uploadFile(userInput.split(" ")[1]);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            default:
                                System.err.println("Wrong input. Choose one:");
                                System.err.println("@upload filename");
                                System.err.println("@exit");
                                break;
                        }
                        System.out.println("File console activated. Please choose form of transfer and file name:");
                    }
                    break;
                default: System.err.println("Wrong choice"); break;
            }
        } catch (UnknownHostException e) {
            System.err.println("Could not recognize host " + host);
        } catch (IOException e) {
            System.err.println("Could not connect with host " + host);
        }
    }

    // odbiór od serwera na netcat
    static class Output extends Thread {
        public void run(){
            try {
                ServerSocket socketu = new ServerSocket(4335);
                Socket socket = socketu.accept();

                BufferedReader in = new BufferedReader (new InputStreamReader (socket.getInputStream ()));
                String cominginText = "";
                while (cominginText != null)
                {
                    cominginText = "";
                    try
                    {
                        cominginText = in.readLine ();
                        System.out.println (cominginText);
                    }
                    catch (IOException e)
                    {
                        //error ("System: " + "Connection to server lost!");
                        System.exit (1);
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Asynchronous OUTPUT closed successfully");
            // close input - REPAIR
        }
    }

    private static void sendWord(String word, int length) {
        // control text length
        if (word.length() < length){
            // translate string to char array
            char[] array = new char[length];
            StringReader arrayReader = new StringReader(word);
            try {
                arrayReader.read(array); //Reads string into the array. Throws IOException
            } catch (IOException e) {
                System.err.println("Translation of " + word + " (length " + word.length() + ") to " + length + " chars array failed!");
                e.printStackTrace();
                System.exit(1);
            }
            // send to host
            out.println(array);
        }else{
            System.err.println("Oversized text (" + word + "), " +
                    "size: "+ word.length() + ", expected: "+ length + "");
        }
    }

    // https://stackoverflow.com/questions/27498845/file-transfer-between-java-client-and-c-server
    private static void uploadFile(String fileName) throws FileNotFoundException {

        System.out.println("Initializing file " + fileName + " upload...");

        // send choice
        sendWord("upload", 32);
        File file = new File(fileName);
        //send file path
        sendWord(fileName, 32);

        // initialize file
        FileInputStream fis;
        fis = new FileInputStream(file);
        System.out.println("File size: "+ file.length() + " bytes");

        // send file size and set bytes array to it
        System.out.println("Sending file size...");
        sendWord(Long.toString(file.length()), 32);
        System.out.println("File size sent successfully");

        byte[] bytes = new byte[1024];

        // send bytes
        System.out.println("Initializing stream...");
        BufferedInputStream bis = new BufferedInputStream(fis);
        OutputStream outStream = null;
        System.out.println("Stream initialized");

        try {
            outStream = serverSocket.getOutputStream();
        } catch (IOException e) {
            System.err.println("Connection with host was lost");
            e.printStackTrace();
        }

        System.out.println("Sending file...");
        int count, i=1;
        try {
            while ((count = bis.read(bytes)) > 0) {
                assert outStream != null;
                outStream.write(bytes, 0, count);
                System.out.println("Package " + i + " sent");i++;
            }
        } catch (IOException e) {
            System.err.println("Connection with host was lost");
            e.printStackTrace();
        }
        System.out.println("Closing subprocedures...");

        // close subprocedure
        try{
            assert outStream != null;
            outStream.flush();
            outStream.close();
            fis.close();
            bis.close();
        } catch (IOException e) {
            System.err.println("Subprocedure closing failed!");
            e.printStackTrace();
        }
        System.out.println("Subprocedure closed");

        // wait for confirmation
        System.out.println("Waiting for confirmation from server...");
        confirmation();
        if(outputFromServer.equalsIgnoreCase("accepted")){
            System.out.println("File upload successful.");
        }else{
            System.out.println("Confirmation failed - received: "+ outputFromServer);
        }
    }


    private static void confirmation(){
        try {
            outputFromServer = in.readLine();
        } catch (SocketException e) {
            System.out.println("Closed connection");
        } catch (IOException e) {
            System.err.println("Confirmation  failed!");
            e.printStackTrace();
        }
    }
}