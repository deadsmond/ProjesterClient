#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>


char message[256]; //for sending user basic massages and use chat
char adresses[512][3]; //list of nicks and adresses of the clients and in which room is assigned to the client right now
char nick[32]; //for receiving a chosen nick
char room[32]; //for reciving a chosen room
unsigned short availableRoom = 0;

//list of available rooms for taking
unsigned short rooms[4][3] = {
	{4325, 1, 0},
	{4326, 2, 0},
	{4327, 3, 0},
	{4328, 4, 0}
};


int fileGet(int sdconnection2){
    char path[32];
    long fileSize, bytesSend, sendTotal, bytesReceived;
    FILE* file;
   
    file = fopen("datafromclient", "a+");
 
    unsigned char bufor[1024];
   
    printf("Waiting for path... \n");
    memset(path, 0, sizeof(path));
    recv(sdconnection2, path, sizeof(path), 0);  
 
    printf("Waiting for file size...\n");
    if (recv(sdconnection2, &fileSize, sizeof(long), 0) != sizeof(long)){
        printf("File size failed\n");
        printf("File may not exist\n");
       
       
        return 1;
    }
   
    fileSize = ntohl(fileSize);
    printf("File size: %ld\n", fileSize);
    printf("----- FILE CONTENT -----\n");
    sendTotal = 0;
    while (sendTotal <= fileSize){
        memset(bufor, 0, sizeof(bufor));
        bytesReceived = recv(sdconnection2, bufor, 1024, 0);
        if (bytesReceived <= 0)
            break;
        sendTotal += bytesReceived;
        fflush(file);
        fflush(stdout);
        fseek ( file , 0, SEEK_CUR);
        fputs(bufor, stdout);
        printf("%ld",bytesReceived);
		fprintf(file, "%s", bufor);
    }
    if (sendTotal != fileSize)
        printf("File receiving failed\n");
    else
        printf("File bytes Received successfuly\n");
 
 
    memset(message, 0, sizeof(message));
    strcpy(message, "confirmation\n");
    send(sdconnection2, message, sizeof(message), 0);
    memset(message, 0, sizeof(message));
 
}
//functions that determines whether any room is available, if yes is assigns one and marks it as used

unsigned short ChooseRoom(){
	for(int i=0; i< 4; i++){
		if (rooms[i][2]==0){
			availableRoom=rooms[i][0];
			rooms[i][2]=1;
			return availableRoom;
		}
		else availableRoom = 0;
	};
};


int main(int argc, char **argv)
{
	char AvailableRoomAsChar [32];
    struct sockaddr_in myaddr, endpoint;
    int sdsocket, sdconnection, addrlen, received;
	char choice [32];
	unsigned short currentAdrressIterator = 0;

    if (argc < 2) {
        printf("Listening default port should be passed as an arugment\n");
        return 1;
    }

	void assignPlaceForAdress(unsigned long a, char * b){
		adresses[currentAdrressIterator][0] = a;
		adresses[currentAdrressIterator][1] = *b;
		currentAdrressIterator+=1;
	};

	//bool that checks whether the nick is already taken
	bool isOnTheList( char * a){
		for(int i=0; i<currentAdrressIterator+1; i++){
			if (adresses[i][1] == *a) return true;
		};
		return false;
	};

	bool isTheRoomAlreadyCreated(char * a){
		char CharRoom[32];
		char CharRoom2[32];
		memset(CharRoom, 0, sizeof(CharRoom));
		memset(CharRoom2, 0, sizeof(CharRoom2));
		sprintf(CharRoom2, "%u\n", *a);
		for(int i=0; i<currentAdrressIterator+1; i++){
			sprintf(CharRoom, "%u\n", adresses[i][2]);
			if(strcmp(CharRoom, CharRoom2) == 0 ){
				availableRoom = adresses[i][2];
				return true;
			}
			memset(CharRoom, 0, sizeof(CharRoom));
		};
		return false;
	};

	int CheckIfRoomActive(){
		int countofActive=0;
		for (int i=0; i<512; i++){
			sprintf(room, "%u\n", adresses[i][2]);
			if(adresses[i][2]>=0){
				countofActive+=1;
			};
		}
		if (countofActive>0){
			return 1;
		}
		else return 0;
	};

	//clear adresses array so that there are no errors with outa bounds or sth
	memset(adresses, 0 , sizeof(adresses));

    sdsocket = socket(AF_INET, SOCK_STREAM, 0);
    addrlen = sizeof(struct sockaddr_in);

    myaddr.sin_family = AF_INET;
    myaddr.sin_port = htons(atoi(argv[1]));
    myaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sdsocket,(struct sockaddr*) &myaddr,addrlen) < 0) {
        printf("bind() nie powiodl sie\n");
        return 1;
    }

    if (listen(sdsocket, 10) < 0) {
        printf("listen() nie powiodl sie\n");
        return 1;
    }

	 
		
	while(1){
		sdconnection = accept(sdsocket, (struct sockaddr*) &endpoint, &addrlen);
		
		memset(room, 0, sizeof(room));
		printf("Waiting for credentials...");
		recv(sdconnection, nick, sizeof(nick), 0);
		recv(sdconnection, room, sizeof(room), 0);
		printf("Credentials received: %s %s", nick, room);
		
		if (isOnTheList(nick)==true){
				memset(message, 0, sizeof(message));
				strcpy(message, "This nick has already been taken, please choose another one\n");
				send(sdconnection, message, sizeof(message), 0);
				memset(message, 0, sizeof(message));
				recv(sdconnection, nick, sizeof(nick), 0);
		}		
			
		else assignPlaceForAdress (endpoint.sin_addr.s_addr, nick);


		
		if (isTheRoomAlreadyCreated(room)==true) {
			send(sdconnection, room, sizeof(room), 0); 
			memset(room, 0, sizeof(room));   
		}
		
		else{
			ChooseRoom();
			if(availableRoom==0){
		            // send no room available error
				memset(message, 0, sizeof(message));
				strcpy(message, "No Room is available right now, try again later\n");
				send(sdconnection, message, sizeof(message), 0);
				memset(message, 0, sizeof(message));
			}
			else{
				memset(AvailableRoomAsChar, 0, sizeof(AvailableRoomAsChar));
				sprintf(AvailableRoomAsChar, "%u\n", availableRoom);
				send(sdconnection, AvailableRoomAsChar, sizeof(AvailableRoomAsChar), 0);
				memset(AvailableRoomAsChar, 0, sizeof(AvailableRoomAsChar)); 
			}
		}
		
		if (fork() == 0){
				printf("Room has been created, working on it right away\n\n\n");
				int roomsdsocket, addrlen2, sdconnection2;
				struct sockaddr_in myaddr2;
				unsigned short RoomForChatPurposes =  availableRoom;

				roomsdsocket = socket(AF_INET, SOCK_STREAM, 0);
    			addrlen2 = sizeof(struct sockaddr_in);

				myaddr2.sin_family = AF_INET;
				
				printf("%u\n\n",availableRoom);
				myaddr2.sin_port = htons(availableRoom);
				myaddr2.sin_addr.s_addr = htonl(INADDR_ANY);

				if (bind(roomsdsocket,(struct sockaddr*) &myaddr2,addrlen2) < 0) {
					printf("bind() nie powiodl sie\n");
					return 1;
				}

				if (listen(roomsdsocket, 10) < 0) {
					printf("listen() nie powiodl sie\n");
					return 1;
				}


				while(1){
					unsigned short CurrentRoom = 0;
					char nick2[32];
					CurrentRoom = availableRoom;
					memset(nick2, 0, sizeof(nick2));
					sprintf(nick2, "%s\n", nick);
					//if user chooses to use chat then it proceeds to using chat, other option is file, which is download/upload a file
					sdconnection2 = accept(roomsdsocket, (struct sockaddr*) &endpoint, &addrlen);

					memset(choice, 0, sizeof(choice));
					recv(sdconnection2, choice, sizeof(choice), 0);

						
					memset(message, 0, sizeof(message));	
						
					
					if(CheckIfRoomActive()==0)break;
					//if (isOnTheList(nick)==false) assignPlaceForAdress (endpoint.sin_addr.s_addr, nick);

					if (strcmp(choice, "chat") == 0){
						memset(message, 0, sizeof(message));
						strcpy(message, "accepted\n");
						send(sdconnection2, message, sizeof(message), 0);
						memset(message, 0, sizeof(message));
						
							if(CheckIfRoomActive()==0)break;
								if(RoomForChatPurposes==4325){
									const char *cmd1 = "gnome-terminal --command=\"./run1.sh\" ";
									system(cmd1);
								}
								else if(RoomForChatPurposes==4326){
									const char *cmd2 = "gnome-terminal --command=\"./run2.sh\" ";
									system(cmd2);
								}
								else if(RoomForChatPurposes==4327){
									const char *cmd3 = "gnome-terminal --command=\"./run3.sh\" ";
									system(cmd3);
								}
								else{
									const char *cmd4 = "gnome-terminal --command=\"./run4.sh\" ";
									system(cmd4);
								}
							
						
					}

					else if(strcmp(choice, "file") == 0){
						memset(message, 0, sizeof(message));
						strcpy(message, "accepted\n");
						send(sdconnection2, message, sizeof(message), 0);
						memset(message, 0, sizeof(message));
						fileGet(sdconnection2);
						
						
					}

					else{
                        memset(message, 0, sizeof(message));
                        strcpy(message, "Wrong choice, try again\n");
                        send(sdconnection2, message, sizeof(message), 0);
						strcpy(choice, "\n");
						recv(sdconnection2, choice, sizeof(choice), 0);
                        memset(message, 0, sizeof(message));

                    }

			}
		}	
		
		else{
			printf("Going back to listening");
			continue;
		}
	};

	close(sdconnection);
    close(sdsocket);
    return 0;
}
